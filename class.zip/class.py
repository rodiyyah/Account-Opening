boys = 5
girls = 6
print(boys + girls)